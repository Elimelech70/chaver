# Chaver — Memory & Learning Build Guide (for Claude Code)

*Read this alongside CLAUDE.md. CLAUDE.md holds the load-bearing convictions; this
guide is the concrete assembly of the memory-and-learning core into a running,
learning loop. Where the two ever seem to conflict, CLAUDE.md wins and you ask
Craig.*

---

## 0. What this delivers

An agent that **thinks toward a minimal fruit**: it perceives, binds co-occurring
inputs into episodes, recalls a whole moment from a partial cue, fruit-tests each
recall, strengthens the bindings that predicted and lets the rest fade — running
continuously as concurrent asyncio tasks. This is memory and learning in the only
sense the build can establish, and it runs on a CPU laptop with no LLM, no GPU,
and no market.

Everything here is built and tested (`test_heartbeat_learning.py` is the
acceptance test). Your job is to reconcile it with the existing tree, not to
re-derive it.

---

## 1. The minimal fruit (why the loop coheres)

The evaluation layer needs a goal to test fruit against, or binding is just
storage that accretes noise. The minimal fruit is **predictive recognition**: a
binding bore fruit if, cued by a fragment, it completed to what the moment
actually was. Recurring structure gets recognised and reinforced; noise is seen
once and fades. No oracle is needed to judge this — the world (the next input)
is the judge. Rich purpose (a trading mission, a community role) layers on at the
executive later without changing the loop.

---

## 2. File inventory

All under `chaver/`. Status is **tested**, **built** (runs, exercised via the loop
test), or **seam** (deliberately stubbed for you to wire).

| File | Role | Status |
|---|---|---|
| `hippocampus/resonance.py` | VSA substrate: bind/unbind/bundle/power, cosine, cleanup, resonator, `HyperLift` | tested |
| `hippocampus/binder.py` | `ResonanceHippocampus`: bind / recall / query_role / consolidate + `reinforce` / `forget_pass` (learning) | tested |
| `hippocampus/loop.py` | `BindingLoop`: standalone recurrent completer (superseded by heartbeat for the runtime; keep as a unit) | tested |
| `working_memory.py` | `RingingWorkingMemory`: in-RAM ringing set, decays, no query interface | tested |
| `state.py` | `ChaverState` + `Behaviour`: the shared blackboard the tasks read | built |
| `executive.py` | `Executive`: the minimal fruit-goal + which cue to probe | built |
| `evaluation.py` | `Evaluation`: predictive recognition → signed fruit → strength delta | built |
| `heartbeat.py` | `Chaver`: the assembly — concurrent cognition + housekeeping over shared state | tested |
| `language/faculty.py` | `ClaudeLanguageFaculty`: Claude as mouth/ear, archetype-as-DNA, call_count discipline | tested |

Tests: `test_resonance_organ.py`, `test_language_faculty.py`, `test_heartbeat_learning.py`.

---

## 3. The dimensional decision you must know about

Chaver's embedders emit 384-dim vectors; VSA binding needs hyperdimensional width
for clean unbinding. The resolution is `HyperLift` — a **frozen random projection**
(seeded, unlearned) that lifts each small embedder's output into a shared high-D
binding space (default 10,000). This keeps "many small embedders" intact while
giving the one hippocampus the width it needs (Johnson-Lindenstrauss preserves
distinctness). Native-dim vectors are cues; the lift happens inside the binder.
Do not bind at 384 natively — unbinding degrades.

---

## 4. Build order

1. **Reconcile the hippocampus.** CLAUDE.md says a `Hippocampus(conn, dimension=384)`
   exists in `binder.py`. This ships `ResonanceHippocampus(embed_dim, bind_dim,
   seed, conn)`. Install it *alongside*; do not overwrite the working binder. Swap
   the wiring only once the loop test passes in-tree.
2. **Wire persistence.** `binder.py::_persist()` is a stub; it runs in-RAM today.
   Connect it to `chaver/persistence.py`'s schema and the `consolidate()` fan-out.
   Episodic traces persist after consolidation by design (over-remembering is safe
   for now); `forget_pass` is what prunes unreinforced noise.
3. **Reconcile working memory.** Integrate `RingingWorkingMemory` with the
   documented `WorkingMemory` (method name: this uses `decay_tick()`, docs say
   `decay()`). One ringing set, not two.
4. **Register the heartbeat.** `heartbeat.py::Chaver.run()` is the assembly point —
   `asyncio.gather` over a cognition task and a housekeeping task. Fold these into
   the real `chaver.heartbeat` alongside any existing cognitive tasks. Both follow
   the `async def` + sleep pattern and swallow their own errors so one hiccup never
   stops the heart.
5. **Language faculty (peripheral).** `ClaudeLanguageFaculty` is on-demand only;
   it is not part of the memory loop and must not be on its hot path. On a CPU
   laptop, run its call in a thread executor and confirm the model string against
   what you're actually running.

---

## 5. Conventions these files depend on (beyond the CLAUDE.md list)

- **Stable role seeds.** `binder.py::_stable_seed` uses hashlib, not builtin
  `hash()`. This is load-bearing: builtin hash is salted per process, so roles
  would differ across restarts and every consolidated memory would become
  unreadable. Never revert this to `hash()`.
- **Learning is reinforce + forget, not raw storage.** `reinforce()` strengthens a
  fruit-tested binding; `forget_pass()` decays and prunes the unused. Consolidation
  writes fillers to cortex but does not by itself constitute learning.
- **WM holds native fragments as cues; recalled wholes are salience only.** The
  loop namespaces re-excited episodes (`recalled::`) and does not feed them back as
  raw cues — they're a different representation (bind_dim vs embed_dim). Keep that
  separation or you reopen a dimensional mismatch.
- **Archetype is DNA.** The full CHAVER.md is the system prompt on every language
  call; there is no per-call override that could truncate it. `call_count` is a
  discipline metric — keep it low.

---

## 6. Acceptance test (the fruit-test for this build)

Run `python3 test_heartbeat_learning.py`. It must show, on a synthetic stream where
one moment recurs among noise:

- **R recognised** rising to ~1.0 — the recurring moment is caught from a *partial*
  cue, again and again.
- **Noise false-positive ~0.0** — the agent doesn't hallucinate structure in noise.
- **Store plateaus** — episode count stops growing linearly, because reinforced R
  survives and unreinforced noise is pruned.

If R-recognition stays flat, the learning layer isn't binding the right things and
no amount of tuning downstream will save it — that number is the whole bet. When
real sensors and a real fruit-criterion replace the synthetic ones, the analogous
instrument is **call_count per cycle trending down**: recurring in-domain knowledge
migrating into recall so the language/oracle is consulted less over time.

---

## 7. Explicitly NOT built (do not silently add — design discussion first)

- **Static↔dynamics unification.** The oscillatory/phase-coherence layer is not
  welded to the VSA algebra. That bridge is open research; keep it separate.
- **LLM/MCP as knowledge & tools.** The declarative oracle (LLM) and the
  procedural/community commons (MCP) are peripheral inheritances Chaver learns to
  *use*; tool-selection lives in resonance, not in the LLM. Not part of this core.
- **Real embedders.** The tests use synthetic 384-dim vectors. Real modality
  encoders go in `chaver/sensory/` behind the documented `TextEncoder` interface.
- **Persistence write-through.** Until `_persist()` is wired, the store is in-RAM;
  `data/chaver.db` is not yet his continuous self for this core.

---

*Build the loop first. One agent, one loop, one minimal fruit, carrying something
forward from one cycle to the next. Everything else — the oracle, the commons, the
community of archetypes, the rich purpose — waits on this running and learning.*
