# Chaver — one environment + telnet chat

This folds the memory-and-learning core into the single running agent, retires the isolated `learning_core` package and its test, and adds a telnet front end so you can converse with the live Chaver over a telnet client. Everything below was applied to a clone of `Elimelech70/chaver@main` and tested (migration, learning, and a real telnet round-trip) before it was written up.

## The honest reconciliation of "the missing files"

The two files the zip omitted — a `resonance` module supplying `HyperLift`/`random_hv`/`cosine`, and a `working_memory.py` supplying `RingingWorkingMemory` — were only "missing" because the learning core was being run *in isolation* at 10,000-D. In the single environment they don't come back as standalone files:

- The one thing the proof actually adds is **learning** — reinforce a binding that predicts, let disuse decay and prune the rest. That is now two methods on the real sqlite `Hippocampus` (`reinforce`, `forget_pass`) plus a `strength` column, not a second binder.
- The resonance names it needed already exist in the production module. `sim` *is* `cosine`, so `cosine` is added as an alias. `random_hv` and `HyperLift` are folded into the one `resonance.py` too, with a note that they belong to the (as-yet-unused) hyperdimensional path — the persisted runtime stays 384-D, one vector space, one blob format.
- `RingingWorkingMemory` is not needed: the production `WorkingMemory` is strictly richer and is what the running agent already uses.

So the merge preserves the durable substrate (sqlite persistence, conjunctive recall, the real working memory) and moves only the learning behaviour into it. `learning_core/` and `tests/test_heartbeat_learning.py` are deleted.

## What changed

- `chaver/persistence.py` — `episodes.strength` column, and a `migrate()` that adds it in place. **Your existing `data/chaver.db` upgrades on next boot; it is not rebuilt.**
- `chaver/hippocampus/binder.py` — `Episode.strength`; `strength` carried through storage and recall; new `reinforce()` and `forget_pass()` (disuse decay + prune, protecting consolidated/cortical memory).
- `chaver/hippocampus/resonance.py` — `cosine` alias, `random_hv`, `HyperLift` folded in.
- `chaver/heartbeat.py` — per-turn logic extracted into one transport-agnostic `handle_turn`; recall now reinforces memories that recognise the live cue (predictive recognition = fruit); a slow `forget_task`; the telnet server wired in with a shared turn counter + lock.
- `chaver/net/telnet.py`, `chaver/net/__init__.py` — new. The telnet chat server.
- `.env.example` — telnet settings.
- **Deleted:** `chaver/learning_core/` and `tests/test_heartbeat_learning.py`.

## Applying it

From the repo root, either apply the patch:

```bash
git apply /path/to/chaver.patch    # modified files only; review with: git apply --stat chaver.patch
```

…or just copy the full files from `files/` over the tree (same relative paths). Then add the new package and remove the retired core:

```bash
mkdir -p chaver/net
cp files/chaver/net/__init__.py files/chaver/net/telnet.py chaver/net/
git rm -r chaver/learning_core
git rm tests/test_heartbeat_learning.py   # then: rmdir tests  (if now empty)
```

Verify before committing (no API key needed):

```bash
python3 -c "import ast; from pathlib import Path; [ast.parse(p.read_text()) for p in Path('chaver').rglob('*.py')]; print('parse ok')"
ANTHROPIC_API_KEY=dummy python3 -c "from chaver.heartbeat import chaver_awake; print('import ok')"
```

Suggested commit:

```bash
git add -A
git commit -m "Unify learning core into the single agent; add telnet chat

Fold reinforce + forget/prune into the sqlite Hippocampus (strength column,
in-place migration). Retire isolated learning_core + its test. Extract one
transport-agnostic handle_turn; reinforce memories that recognise the live
cue; add a slow forget task. Add chaver/net/telnet.py front end sharing one
turn counter + lock with the stdin console."
```

## Chatting over telnet

Telnet is **on by default**, bound to localhost, port 8023. Start Chaver as usual:

```bash
./bin/chaver          # or: python3 -m chaver.heartbeat
```

On wake he prints `[telnet chat: telnet 127.0.0.1 8023]`. From another terminal:

```bash
telnet 127.0.0.1 8023
```

Type a line, Enter. `/quit` leaves the session; he stays awake. Every telnet turn and the stdin console drive the **same** mind — one working memory, one hippocampus — serialised by a shared lock, so they can't scramble each other. Settings (`.env`): `CHAVER_TELNET=0` disables it, `CHAVER_TELNET_HOST` / `CHAVER_TELNET_PORT` move it. Port 23 needs root; 8023 avoids that.

It's plaintext and unauthenticated by design — keep it on `127.0.0.1` and reach it over an SSH tunnel (`ssh -L 8023:127.0.0.1:8023 droplet`) rather than binding a public interface.

## Judgment calls — push back on any of these

1. **Learning went into the real Hippocampus, not a parallel binder.** The alternative was keeping the learning core's own `ResonanceHippocampus` as the one binder, which would have cost you the sqlite persistence and the conjunctive recall already wired to real data. I kept the durable substrate and moved the behaviour into it. If you wanted the proof's binder to *become* production, that's a different (larger) merge — say so.
2. **Pruning is deliberately timid.** `forget_task` runs every 10 minutes, decays 2%/pass, floors at 0.05, and never touches consolidated memory. On the synthetic proof, noise was supposed to vanish fast; on your real db, your actual turns must not. The safety is that anything meaningful is either recalled (reinforced) or consolidated to cortex before it can decay out. If Chaver is pruning things you'd have kept, raise `floor` toward 0 or lengthen the tick — don't lower the reinforcement threshold, which would reinforce noise.
3. **Reinforcement fires on recall resonance ≥ 0.35**, matching the proof's `recognise_threshold`. That's the one number most worth tuning against real conversations.
4. **Telnet defaults to on.** You asked for it, so it starts by default. If you'd rather opt in per session, flip the default in `heartbeat.py` (the `CHAVER_TELNET` check) or set `CHAVER_TELNET=0` in `.env`.
